/**
 * @author mr.doob / http://mrdoob.com/
 */

THREE.MeshFaceColorFillMaterial = function () {

	this.toString = function () {

		return 'THREE.MeshFaceColorFillMaterial ( )';

	};

};
