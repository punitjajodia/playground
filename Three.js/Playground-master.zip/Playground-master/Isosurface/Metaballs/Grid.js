var Grid = {
  x: {
    from: -1.6,
    to: 1.6,
    step: 0.2
  },
  y: {
    from: -1.6,
    to: 1.6,
    step: 0.2
  },
  z: {
    from: -1.6,
    to: 1.6,
    step: 0.2
  }
};
