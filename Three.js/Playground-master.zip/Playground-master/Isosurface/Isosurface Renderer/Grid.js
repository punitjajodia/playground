var Grid = {
  x: {
    from: -1,
    to: 1,
    step: 0.1
  },
  y: {
    from: -1,
    to: 1,
    step: 0.1
  },
  z: {
    from: -1,
    to: 1,
    step: 0.1
  }
};
