/**
 * @author mr.doob / http://mrdoob.com/
 */

THREE.MeshFaceMaterial = function () {

	this.toString = function () {

		return 'THREE.MeshFaceMaterial';

	};

};
