/**
 * @author mr.doob / http://mrdoob.com/
 */

THREE.FlatShading = 0;
THREE.SmoothShading = 1;

THREE.NormalBlending = 0;
THREE.AdditiveBlending = 1;
THREE.SubtractiveBlending = 2;
