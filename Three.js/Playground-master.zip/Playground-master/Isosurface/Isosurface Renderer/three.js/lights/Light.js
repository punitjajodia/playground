THREE.Light = function ( hex ) {

	this.color = new THREE.Color( 0xff << 24 | hex );

};
