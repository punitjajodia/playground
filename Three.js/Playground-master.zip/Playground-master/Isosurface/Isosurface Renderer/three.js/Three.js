/**
 * @author mr.doob / http://mrdoob.com/
 */

var THREE = THREE || {};
